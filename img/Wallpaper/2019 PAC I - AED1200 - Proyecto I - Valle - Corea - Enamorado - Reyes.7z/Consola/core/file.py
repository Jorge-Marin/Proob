# -*- coding: utf-8 -*-
class File:
	def __init__(self,valor):
		self.valor = valor

	def getValor(self):
		return self.valor
		
	def setValor(self,valor):
		self.valor = valor
