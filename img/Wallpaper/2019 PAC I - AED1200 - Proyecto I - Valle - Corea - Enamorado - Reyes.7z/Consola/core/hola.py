ejmplo = "Hola/como"
if ejemplo.find("/"):
	print "Existe"
else:
	print("Hola")