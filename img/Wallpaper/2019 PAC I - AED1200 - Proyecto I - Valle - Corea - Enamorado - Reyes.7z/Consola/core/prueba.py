name = "FOlder"
lista = []
diccionario = {'type':'file','name':'hola.txt'}
lista.append(diccionario)
dic = {'type':'Folder','name':str(name),'Children ': lista}

print(dic)